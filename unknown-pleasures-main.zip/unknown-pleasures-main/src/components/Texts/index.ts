export { default } from "./Texts";
