export { default } from "./Stars";
